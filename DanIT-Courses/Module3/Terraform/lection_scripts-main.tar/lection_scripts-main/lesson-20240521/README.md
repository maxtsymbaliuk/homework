# Ansible Basic
- [Install](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html)
- [Inventory](https://docs.ansible.com/ansible/latest/inventory_guide/intro_inventory.html)
- [Variables](https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_variables.html)
- [Conditions](https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_conditionals.html)
- [Main Modules](https://faun.pub/ansible-30-most-important-modules-for-devops-professional-part-1-fdd536b0790d)
- [Default Modules](https://docs.ansible.com/ansible/latest/collections/ansible/builtin/index.html)
