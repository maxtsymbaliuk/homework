#using pip (pip3) 
pip install diagrams
# create diagrams
python3 diagrams.py
