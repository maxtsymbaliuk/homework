# Container Registry

## Documentation
- [Docker Registry](https://distribution.github.io/distribution/about/deploying/)
- [Nexus](https://ahgh.medium.com/how-to-setup-sonatype-nexus-3-repository-manager-using-docker-7ff89bc311ce)
- [Nexus Remote Registry](https://help.sonatype.com/en/proxy-repository-for-docker.html)
- [jFrog Artifactory](https://jfrog.com/help/r/jfrog-installation-setup-documentation/install-artifactory-single-node-with-docker)
- [jFrog Remote Repository](https://jfrog.com/help/r/jfrog-artifactory-documentation/remote-docker-repositories)

## Registry
```bash
mkdir -p $(pwd)/registry
chmod -R 777 $(pwd)/registry
sudo docker run -d -p 5000:5000 --restart=always --name registry -v $(pwd)/registry:/var/lib/registry registry:2
```

## Python
```bash
cd python
sudo docker build -t localhost:5000/python-app .
sudo docker push localhost:5000/python-app
sudo docker run localhost:5000/python-app
```

## Nexus
```bash
mkdir -p $(pwd)/nexus-data
chmod -R 777 $(pwd)/nexus-data
sudo docker run -d -p 3000:8081 -p 5000:5000 --name nexus -v $(pwd)/nexus-data:/nexus-data klo2k/nexus3
cat $(pwd)/nexus-data/admin.password

sudo docker login localhost:5000
sudo docker pull localhost:5000/ubuntu
```

## jFrog
```bash
export JFROG_HOME=$(pwd)/jfrog
mkdir -p $JFROG_HOME/artifactory/var/etc/
touch $JFROG_HOME/artifactory/var/etc/system.yaml
sudo chown -R 1030:1030 $JFROG_HOME/artifactory/var
sudo chmod -R 777 $JFROG_HOME/artifactory/var
sudo docker run --name artifactory -v $JFROG_HOME/artifactory/var/:/var/opt/jfrog/artifactory -d -p 3000:8081 -p 5000:8082 releases-docker.jfrog.io/jfrog/artifactory-oss:latest
```
