#!/usr/bin/env python3

import json
import requests
import sys
from colorama import init
from termcolor import colored 
from web_checker import web_check
init()

file_path = sys.argv[1]

f = open(file_path)
content = f.read()
config = json.loads(content)

for web_site in config.keys():
  web_check(config[web_site])


