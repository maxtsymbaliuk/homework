import React from 'react'

const FirstTest = () => {
  return (
    <div>
        <h2> First test </h2>
        
    </div>
  )
}

export default FirstTest