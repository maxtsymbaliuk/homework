Plan:
- Private Key
- ToSet vs For In
- try
- 