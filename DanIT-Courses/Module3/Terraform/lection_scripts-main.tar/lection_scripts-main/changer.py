#!/usr/bin/python3

import fileinput
from git import Repo
from pathlib import Path
import os

#import subprocess

home_directory = Path.home()
repo_url = "git@github.com:dan-test-it/DanIT.git"
repo_name = "Documents/work/DanIT/change/"
path_to_file = "Documents/work/DanIT/change/terraform/variable.tf"
terraform_path = home_directory / path_to_file

    
#Clone GitHub Repo 
# def clone_repo():
#     local_path = home_directory / repo_name
#     try:
#         Repo.clone_from(repo_url, local_path)
#         print(f"Repo is clonnig in {local_path}")
#     except Exception as e:
#         print(f"Error with clonning repo: {e}")
def change_param():
    with open(home_directory/"Documents/work/DanIT/change/terraform/variable.tf", "r")as f:
        data = f.read()
    print("start replace something")

    data = data.replace("us-east-2", "us-east-1")
    data = data.replace("danit_staging", "danit_test")
    data = data.replace("stag", "dev")



    print("finish replace some stuff")

    with open(home_directory/"Documents/work/DanIT/change/terraform/variable.tf", "w") as f:
        f.write(data)
# def update_terraform_file():
#     try:
#         with fileinput.input(terraform_path,inplace=True) as file:
#             for line in file:
#                 print(line.replace(region_variable_name, "variable"), end='')
#                 print("yes")
#             fileinput.close()
#         print("file succesfully edited")
#     except Exception as e:
#         print("Error with edit {e}")
    
def commit_changes():
    try:
        print("ho-ho")
        repo.git.add("-A")
    #repo.index.commit("Add some shit")
        print("commit successfully added")
    except Exception as e:
        print(f"error with {e}")

repo = Repo("../change/terraform")

# clone_repo()
change_param()
#update_terraform_file()
commit_changes()