# default-react-app

React Boiler plate setup with Redux, webpack, babel.

There is a default area with default Container/component, and default Selector, actions, reducers and sagas files.
