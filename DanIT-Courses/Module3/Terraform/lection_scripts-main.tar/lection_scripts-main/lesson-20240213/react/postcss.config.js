module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-nested': {},
    'postcss-at-rules-variables': {}
  }
};
