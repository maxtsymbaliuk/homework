# Docker Compose

## Documentation
- [Docker Compose](https://docs.docker.com/compose/)
- [Syntax](https://docs.docker.com/compose/compose-file/compose-file-v3/)

## Use Cases
- Document container service settings
- Work with multiple projects simultaneously
- Connect different parts of solution together

## Adminer
```bash
cd adminer
sudo docker compose up
```

## React
[Example App](https://github.com/murreng/default-react-app)
```bash
cd react
npm install
NODE_OPTIONS=--openssl-legacy-provider npm run build
sudo docker compose build
sudo docker compose up
```
