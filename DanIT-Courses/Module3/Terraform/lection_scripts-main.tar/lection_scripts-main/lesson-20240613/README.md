### Kind
1. Create/delete cluster
2. worker node
3. ports mapping
4. volumes mapping

### Minikube
1. Create/delete cluster
2. ports mapping
3. volumes mapping

### Port forward
1. kubectl proxy

### Kube context
1. Switch between clusters
