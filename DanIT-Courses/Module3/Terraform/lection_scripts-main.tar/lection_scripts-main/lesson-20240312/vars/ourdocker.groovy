def registry () {
    return env.REGISTRY ?: 'registry.gitlab.com'
}

def cmd (Closure body) {
    withCredentials([usernamePassword(credentialsId: 'gitlab-registry', passwordVariable: 'DOCKER_PASSWORD', usernameVariable: 'DOCKER_USER')]) {
        sh "docker login ${this.registry()} -u ${DOCKER_USER} -p ${DOCKER_PASSWORD}"
        body()
    }
}

def build(image) {
    echo 'Build image'
    this.cmd {
        sh "docker build -t ${this.registry()}/${image} ."
    }
}

def push(image) {
    echo 'Push image'
    this.cmd {
        sh "docker push ${this.registry()}/${image}"
    }
}