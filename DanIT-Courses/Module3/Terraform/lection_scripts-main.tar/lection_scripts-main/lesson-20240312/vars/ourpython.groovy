def call(Closure body) {
    docker.image('python:3.9-slim').inside {
        body()
    }
}
