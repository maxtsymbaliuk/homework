// src/it/dan/DevOps.groovy
package it.dan

def checkOutFrom(Map conf) {
  def repo = conf.repo
  def branch = conf.branch ? conf.branch : 'main'
  def creds = conf.creds ? conf.creds : 'ssh-key'
  def group = conf.group ? conf.group : 'git@gitlab.com:dan-it/groups'

  git branch: branch,
    credentialsId: creds,
    url: "${group}/${repo}"
}

def cleanUp() {
    sh 'rm -rf *'
}

return this
