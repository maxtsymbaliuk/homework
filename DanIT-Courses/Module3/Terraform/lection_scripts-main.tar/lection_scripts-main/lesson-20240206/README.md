# Linux

## Check free space on disks
```
df -h
```
## Check memory
```
free -h
```

## Check list of processes
```
ps aux
top
htop
```

## Stop processes
```
kill PID
kill -9 PID
```

## Continuously check for updates
```
watch ls -lha
while [ 1 ]; do clear; ls -lha | grep python; sleep 2; done
```

# GIT
## Create repository
```
git init
```

## Create branch
```
git checkout -b branch-name
```
```
git branch branch-name
git checkout branch-name
```

## Cancel all uncommitted changes
```
git checkout -- .
```

## Cancel committed changes
```
git reset HEAD^1
git reset --hard HEAD^1
```

## How to update your custom branch to latest stable code
```
git rebase master feature1
```

## Remove all untracked files
```
git clean -f
```

## Remove all untracked folders
```
git clean -f -d
```

# DNS
```
A - IPv4
AAAA - IPv6
SOA - Domain
MX - Mail
TXT - Additional settings
PTR - Reverse DNS
```
