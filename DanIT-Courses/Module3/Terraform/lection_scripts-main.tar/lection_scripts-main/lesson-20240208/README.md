# Build a nodejs docker app

## Documentation
- [Dockerfile reference](https://docs.docker.com/engine/reference/builder/)
- [ARG + FROM](https://docs.docker.com/engine/reference/builder/#understand-how-arg-and-from-interact)
- [docker build](https://docs.docker.com/engine/reference/commandline/image_build/)
- [docker run](https://docs.docker.com/engine/reference/commandline/container_run/)

## Examples
```bash
# Build image and pass arguments to control settings
docker build --build-arg TAG=latest .
# Pass env variable to container and output its value
docker run -it --rm --env TEST=test ubuntu:latest bash -c 'echo $TEST'
# Pass file to container and output its content
docker run -it --rm -v $(pwd)/vagrant_script:/vagrant_script ubuntu:latest cat /vagrant_script
# Pass script from OS to container and use it as entrypoint
docker run -it --rm -v $(pwd)/script.sh:/script.sh --entrypoint=/script.sh python:latest
```


## NodeJs
```bash
cd nodejs
docker build -t nodejs-app .
docker run nodejs-app
```
