#!/bin/bash
yum install docker -y
