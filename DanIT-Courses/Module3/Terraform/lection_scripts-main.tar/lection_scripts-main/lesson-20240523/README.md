### Ansible
1. Repeat main moments from previous lesson
2. Popular modules
3. Roles
4. Run ansible in terraform
