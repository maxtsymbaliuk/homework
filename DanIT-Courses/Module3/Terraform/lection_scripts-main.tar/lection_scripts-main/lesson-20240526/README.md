### Ansible
1. Repeat [ansible-galaxy](https://docs.ansible.com/ansible/latest/cli/ansible-galaxy.html) for [collections](https://docs.ansible.com/ansible/latest/collections/community/docker/index.html) and [roles](https://galaxy.ansible.com/ui/standalone/roles/sebastian13/docker-nginx-proxy/documentation/)
2. Use requirements to install [dependencies](https://galaxy.ansible.com/ui/standalone/roles/sebastian13/docker-nginx-proxy/documentation/)
3. Use tags
4. ansible-vault
