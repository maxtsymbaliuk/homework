### Ansible
1. Q/A session
2. Setup infrastructure from the article: https://www.padok.fr/en/blog/prometheus-monitoring-ansible https://github.com/padok-team/ansible-monitoring-stack
3. Describe step project tasks
